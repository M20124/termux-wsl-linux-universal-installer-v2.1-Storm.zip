(тут код storm-installer.sh який я тобі давав раніше)
